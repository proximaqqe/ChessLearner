import os, sys
import webview

def resource_path(relative):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)

if __name__ == "__main__":
    page = resource_path(os.path.join("www", "index.html"))
    webview.create_window("ChessLearner", "file://" + page, width=1180, height=850, min_size=(360, 600))
    webview.start()
