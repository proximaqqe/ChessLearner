# ChessLearner — проект для Windows и Android

Это исходный проект, а не уже собранные бинарные файлы. Он содержит один интерфейс для настольной и Android-версии.

## Что уже работает
- интерактивная шахматная доска;
- проверка легальности ходов с помощью `chess.js`;
- предложение простого легального хода (не полноценный шахматный поиск);
- импорт PGN и подсчёт частот SAN-ходов;
- экспорт модели/партий в JSON, PGN, CSV и конфигурацию UCI;
- адаптивный интерфейс.

## Сборка на Windows в EXE

1. Установите Node.js LTS и Python 3.11+.
2. Распакуйте проект и откройте терминал в папке `ChessLearner`.
3. Выполните:

```powershell
npm install
npm run build
py -m pip install -r requirements-desktop.txt
py -m PyInstaller --noconfirm --clean desktop/chesslearner.spec
```

Файл будет в `dist/ChessLearner.exe`. Для более предсказуемой сборки используйте Windows: PyInstaller не создаёт Windows EXE при запуске на Linux/macOS. WebView2 Runtime может понадобиться на старых Windows-системах.

## Сборка Android APK

Нужны Node.js LTS, JDK 17 и Android Studio с Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

В Android Studio дождитесь синхронизации Gradle, затем выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**. APK обычно находится в `android/app/build/outputs/apk/debug/`. Для публикации создайте подписанную release-сборку в Android Studio.

Если папка `android/` уже создана ранее, не запускайте `npx cap add android` повторно — используйте `npx cap sync android`.

## Важно о шахматном движке

Сейчас это учебный прототип. Он **не** является Stockfish и не реализует сильный поиск, оценку позиции, полноценное обучение нейросети или протокол UCI для реальной игры. UCI-экспорт — лишь JSON-шаблон. Для движка турнирного уровня потребуется интеграция настоящего UCI-совместимого движка (например, Stockfish с соблюдением его лицензии) либо отдельная разработка ядра и алгоритма поиска.

Данные и партии сохраняются в памяти сессии; скачивайте экспорт, если хотите сохранить результаты между запусками. Обработка файлов выполняется локально в интерфейсе.

## Автоматическая сборка через GitHub Actions

В `.github/workflows/` добавлены отдельные workflows для Windows EXE и Android APK.
1. Создайте приватный или публичный репозиторий GitHub и загрузите туда содержимое проекта.
2. Откройте вкладку **Actions** и разрешите запуск workflows, если GitHub попросит.
3. Выберите **Build Windows EXE** → **Run workflow** и отдельно **Build Android APK** → **Run workflow**.
4. После успешного завершения скачайте EXE/APK из раздела **Artifacts** соответствующего запуска.

Это создаёт отладочный APK, не подписанный для публикации в Google Play. Для релизной Android-сборки нужна подпись. Первый запуск также может выявить несовместимости зависимостей, которые потребуется исправить.

\n## Автоматическая сборка через GitHub с телефона\n\nВ архив включён workflow `.github/workflows/build.yml`. После загрузки содержимого проекта в репозиторий GitHub:\n1. Открой репозиторий в браузере телефона.\n2. Перейди в **Actions** и разреши запуск Actions, если GitHub предложит.\n3. Выбери **Build ChessLearner EXE and APK** и нажми **Run workflow** после того, как файл workflow появился в основной ветке. Либо сборка стартует автоматически после push в `main`/`master`.\n4. Дождись завершения обоих jobs.\n5. Открой запуск и скачай `ChessLearner-Windows-EXE` и `ChessLearner-Android-APK` из Artifacts.\n\nЗагружай в репозиторий распакованное содержимое проекта, включая скрытую папку `.github`. Один ZIP-файл без распаковки не запускает workflow.\n