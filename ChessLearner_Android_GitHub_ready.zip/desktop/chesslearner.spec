# Build from project root: pyinstaller --noconfirm --clean desktop/chesslearner.spec
from PyInstaller.utils.hooks import collect_all
datas, binaries, hiddenimports = [], [], []
for package in ["webview"]:
    d, b, h = collect_all(package)
    datas += d
    binaries += b
    hiddenimports += h
a = Analysis(["desktop/launcher.py"], pathex=["."], binaries=binaries, datas=datas + [("www", "www")], hiddenimports=hiddenimports, hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False, optimize=0)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name="ChessLearner", debug=False, bootloader_ignore_signals=False, strip=False, upx=True, console=False)
